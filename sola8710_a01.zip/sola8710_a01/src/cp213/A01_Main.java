package cp213;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class A01_Main {
	
	public static final String SEP = "-".repeat(40);
    public static final String CIPHERTEXT = "AVIBROWNZCEFGHJKLMPQSTUXYD"; // for testing substitute method

    public static void main(String[] args) {
    	boolean a;
    	int [] intArray = new int[] {1,2,3,4,5,6,7,8,9};
    	double[][] matrix = {{1,2,3,4},{5,6,7,8},{0,0,0,0},{1,3,5,7}};
    	
    	double[]result = new double[4];
    	
    	int test_harmonic = 5;
    	double result_harmonic = 0.000;
    	    	
    	a = cp213.A01.contains(intArray, 10);
    	System.out.println(a);
    	
    	System.out.println(SEP);
    	
    	a = cp213.A01.isPalindrome("racecar");
    	System.out.println(a);
    	
    	System.out.println(SEP);
    	
    	a = cp213.A01.isValid("_hs123");
    	System.out.println(a);
    	
    	System.out.println(SEP);
    	
    	result = cp213.A01.matrixStats(matrix);
    	for (int i =0;i  < result.length ; i++)

    		System.out.println(result[i]);
    	
    	System.out.println(SEP);
    	
    	result_harmonic = cp213.A01.sumPartialHarmonic(test_harmonic);
        	System.out.printf("Sum is %.3f\n", result_harmonic);  
    	
        System.out.println(SEP);
        	
    	a = cp213.A01.validSn("SN/1234-567");
    		System.out.println(a);
    	

   }

}
