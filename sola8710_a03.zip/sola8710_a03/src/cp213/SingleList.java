package cp213;

/**
 * A simple linked list structure of <code>Node T</code> objects. Only the
 * <code>T</code> data contained in the stack is visible through the standard
 * list methods. Extends the <code>SingleLink</code> class, which already
 * defines the head node, length, iterator, and toArray.
 *
 * @author your name here
 * @version 2021-02-05
 * @param <T> this SingleList data type.
 */
public class SingleList<T extends Comparable<T>> extends SingleLink<T> {

    /**
     * Searches for the first occurrence of key in this SingleList. Private helper
     * methods - used only by other ADT methods.
     *
     * @param key The value to look for.
     * @return A pointer to the node previous to the node containing key.
     */
    private SingleNode<T> linearSearch(final T key) {

    	SingleNode<T> curr = this.front;
        while(curr!=null){
            if(curr.getData().equals(key)){
                return curr;
            }
            curr = curr.getNext();
        }
        return null;

    }

    /**
     * Appends data to the end of this SingleList.
     *
     * @param data The data to append.
     */
    public void append(final T data) {

    	if(this.front==null){
    		this.front = new SingleNode<>(data,null);
    		} else {
    		            SingleNode<T> curr = this.front;
            while(curr!=null){
                if(curr.getNext()==null){
                    curr.setNext(new SingleNode<>(data, null));
                    break;
                }
                curr = curr.getNext();
            }

    	}

    }

    /**
     * Removes duplicates from this SingleList. The list contains one and only one
     * of each value formerly present in this SingleList. The first occurrence of
     * each value is preserved.
     */
    public void clean() {

    	SingleNode<T> key =this.front;
    	while(key!=null) {
    		SingleNode<T> prev=key;
    		SingleNode<T> curr=key.getNext();
    		while(curr!=null)
    		{
    			if (curr.getData().compareTo(key.getData())==0) {
    				this.length--;
    				prev.setNext(curr.getNext());	
    			}
    			else {
    				prev=curr;
    			}
    			curr=curr.getNext();
    			
    		}
    		key=key.getNext();
    	}

    }

    /**
     * Combines contents of two lists into a third. Values are alternated from the
     * origin lists into this SingleList. The origin lists are empty when finished.
     * NOTE: data must not be moved, only nodes.
     *
     * @param left  The first list to combine with this SingleList.
     * @param right The second list to combine with this SingleList.
     */
    public void combine(final SingleList<T> left, final SingleList<T> right) {
    	while(!left.isEmpty() && !right.isEmpty() ) {
    		this.moveFront(left);
    		this.moveFront(right);
    	}
    	while(left.front!=null) {
    		this.moveFront(left);

    	}
    	while (right.front!=null) {
    		this.moveFront(right);
    		
    	}

    }

    /**
     * Determines if this SingleList contains key.
     *
     * @param key The key value to look for.
     * @return true if key is in this SingleList, false otherwise.
     */
    public boolean contains(final T key) {

    	 SingleNode<T> curr = this.front;
         while(curr!=null){
             if(curr.getData().equals(key)){
                 return true;
             }
             curr = curr.getNext();
         }
         return false;

    }

    /**
     * Finds the number of times key appears in list.
     *
     * @param key The value to look for.
     * @return The number of times key appears in this SingleList.
     */
    public int count(final T key) {

    	int n = 0;
    	SingleNode<T> current = this.front;

    	while (current != null) {
    	    if (current.getData().compareTo(key) == 0) {
    		n++;
    	    }
    	    current = current.getNext();
    	}
    	return n;

    }

    /**
     * Finds and returns the value in list that matches key.
     *
     * @param key The value to search for.
     * @return The value that matches key, null otherwise.
     */
    public T find(final T key) {

    	T val = null;

    	if (this.length > 0) {
    	    final SingleNode<T> previous = this.linearSearch(key);

    	    if (previous == null) {
    		val = this.front.getData();
    	    } else if (previous.getNext() != null) {
    		val = previous.getNext().getData();
    	    }
    	}
    	return val;

    }

    /**
     * Get the nth item in this SingleList.
     *
     * @param n The index of the item to return.
     * @return The nth item in this SingleList.
     * @throws ArrayIndexOutOfBoundsException if n is not a valid index.
     */
    public T get(final int n) throws ArrayIndexOutOfBoundsException {

    	SingleNode<T>current=this.front;
        int in = 0;
        while(in<n) {
            current=current.getNext();
            in++;
        }
        return current.getData();

    }

    /**
     * Determines whether two lists are identical.
     *
     * @param source The list to compare against this SingleList.
     * @return true if this SingleList contains the same values in the same order as
     *         source, false otherwise.
     */
    public boolean identical(final SingleList<T> source) {

    	if(this.getLength()!= source.getLength())
            return false;

        SingleNode<T> g1 = this.front, g2 = source.front;
        while(g1!=null && g2!=null){
            if(g1.getData().compareTo(g2.getData())!=0){
                return false;    
            }
            g1 = g1.getNext();
            g2 = g2.getNext();
            
        }
        return true;

    }

    /**
     * Finds the first location of a value by key in this SingleList.
     *
     * @param key The value to search for.
     * @return The index of key in this SingleList, -1 otherwise.
     */
    public int index(final T key) {

    	SingleNode<T> curr = this.front;
        int ir=0;
        while(curr!=null){
            if(curr.getData().compareTo(key)==0){
                return ir;
            }
            curr = curr.getNext();
            ir++;
        }
        return -1;

    }

    /**
     * Inserts data into this SingleList at index i. If i greater than the length of
     * this SingleList, append value to the end of this SingleList.
     *
     * @param i    The index to insert the new value at.
     * @param data The new value to insert into this SingleList.
     */
    public void insert(int i, final T data) {

	// your code here

    }

    /**
     * Inserts data into the front of this SingleList.
     *
     * @param data The value to insert into the front of this SingleList.
     */
    public void prepend(final T data) {

	// your code here

    }

    /**
     * Finds the maximum value in this SingleList.
     *
     * @return The maximum value.
     */
    public T max() {

    	SingleNode<T> curr = this.front;
        T max = curr.getData();
        while(curr!=null){
            if(max.compareTo(curr.getData())<0){
                max = curr.getData();
            }
            curr = curr.getNext();
        }
        return max;

    }

    /**
     * Finds the minimum value in this SingleList.
     *
     * @return The minimum value.
     */
    public T min() {

    	SingleNode<T> curr = this.front;
        T min = curr.getData();
        while(curr!=null){
            if(min.compareTo(curr.getData())>0){
                min = curr.getData();
            }
            curr = curr.getNext();
        }
        return min;

    }

    /**
     * Finds, removes, and returns the value in this SingleList that matches key.
     *
     * @param key The value to search for.
     * @return The value matching key, null otherwise.
     */
    public T remove(final T key) {

   	 if(this.front==null)
         return null;
     if(this.front.getData().compareTo(key)==0){
         this.front = this.front.getNext();
     } else{
         SingleNode<T> cur = this.front;
         while(cur.getNext()!=null){
             if(cur.getNext().getData().compareTo(key)==0){
                 cur.setNext(cur.getNext().getNext());
             }
             cur = cur.getNext();
         }
     }
     return key;

    }

    /**
     * Removes the value at the front of this SingleList.
     *
     * @return The value at the front of this SingleList.
     */
    public T removeFront() {

    	T temp = this.front.getData();
        front = this.front.getNext();
        return temp;

    }

    /**
     * Reverses the order of the values in this SingleList.
     */
    public void reverse() {

    	SingleNode<T> newHead = null;
    	SingleNode<T> temp = null;

    	while (this.front != null) {
    	    temp = this.front.getNext();
    	    this.front.setNext(newHead);
    	    newHead = this.front;
    	    this.front = temp;
    	}
    	this.front = newHead;
    	return;

    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move data or call the high-level methods insert
     * or remove. this SingleList is empty when done. The first half of this
     * SingleList is moved to left, and the last half of this SingleList is moved to
     * right. If the resulting lengths are not the same, left should have one more
     * item than right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void split(final SingleList<T> left, final SingleList<T> right) {

    	SingleNode<T> slo=this.front, fas = this.front, r=null;

        while(fas!=null && fas.getNext()!=null){
            r = slo;
            slo = slo.getNext();
            fas = fas.getNext().getNext();
        }
        if(fas==null){
           right.front = slo;
           left.front = this.front;
           r.setNext(null);
           this.front = null;
        } else{
            left.front = this.front;
            right.front = slo.getNext();
            slo.setNext(null);
            this.front = null;
        }

    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move data or call the high-level methods insert
     * or remove. this SingleList is empty when done. Nodes are moved alternately
     * from this SingleList to left and right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void splitAlternate(final SingleList<T> left, final SingleList<T> right) {

    	SingleNode<T> leftT=left.front, rightT=right.front, curr = this.front;
        while(leftT!=null && leftT.getNext()!=null){
            leftT = leftT.getNext();
        }
        while(rightT!=null && rightT.getNext()!=null){
            rightT = rightT.getNext();
        }

        while(curr!=null && curr.getNext()!=null){
            leftT.setNext(new SingleNode<>(curr.getData(), null));
            leftT = leftT.getNext();

            curr = curr.getNext();

            rightT.setNext(new SingleNode<>(curr.getData(), null));
            rightT = rightT.getNext();

        }

    }

    /**
     * Creates a union of two other SingleLists into this SingleList. Copies data to
     * this list. left and right SingleLists are unchanged.
     *
     * @param left  The first SingleList to create a union from.
     * @param right The second SingleList to create a union from.
     */
    public void union(final SingleList<T> left, final SingleList<T> right) {

    	HashSet<T> Hset = new HashSet<>();
        SingleNode<T> curr = left.front;
        while(curr!=null){
            Hset.add(curr.getData());
            curr = curr.getNext();
        }
        curr = right.front;
        while(curr!=null){
            Hset.add(curr.getData());
            curr = curr.getNext();
        }
        curr = this.front;
        while(curr!=null && curr.getNext()!=null){
            curr = curr.getNext();
        }
        for(T data: Hset){
            if(curr==null){
                this.front = new SingleNode<>(data, null);
                curr = this.front;
            } else{
                curr.setNext(new SingleNode<>(data, null));
                curr = curr.getNext();
            }
        }

    }
}