package cp213;

/**
 * @author 
 * @version 2021-09-12
 */
public class Cipher {
    // Constants
    public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final int ALPHA_LENGTH = ALPHA.length();

    /**
     * Encipher a string using a shift cipher. Each letter is replaced by a letter
     * 'n' letters to the right of the original. Thus for example, all shift values
     * evenly divisible by 26 (the length of the English alphabet) replace a letter
     * with itself. Non-letters are left unchanged.
     *
     * @param s string to encipher
     * @param n the number of letters to shift
     * @return the enciphered string
     */
    public static String shift(final String s, final int n) {
    	String shifted = "";
        char upper = ' ';
    	
    	if(n>26) {
    		int shift_amt = n%26;   		
        	for (int i = 0; i < s.length(); i++) {
                if(Character.isLetter(s.charAt(i))){
                    upper = Character.toUpperCase(s.charAt(i));
                    int temp = ALPHA.indexOf(upper);
                    char new_char = ALPHA.charAt(temp+shift_amt);
                    shifted += new_char; 
                }

    		}
    	}
    	else {
        	for (int i = 0; i < s.length(); i++) {
                if(Character.isLetter(s.charAt(i))){
                    upper = Character.toUpperCase(s.charAt(i));
                    int temp = ALPHA.indexOf(upper);
                    char new_char = ALPHA.charAt(temp+n);
                    shifted += new_char;  
                }
        	}
    	}

	return shifted;
    }

    /**
     * Encipher a string using the letter positions in ciphertext. Each letter is
     * replaced by the letter in the same ordinal position in the ciphertext.
     * Non-letters are left unchanged. Ex:
     *
     * <pre>
    Alphabet:   ABCDEFGHIJKLMNOPQRSTUVWXYZ
    Ciphertext: AVIBROWNZCEFGHJKLMPQSTUXYD
     * </pre>
     *
     * A is replaced by A, B by V, C by I, D by B, E by R, and so on. Non-letters
     * are ignored.
     *
     * @param s          string to encipher
     * @param ciphertext ciphertext alphabet
     * @return the enciphered string
     */
    public static String substitute(final String s, final String ciphertext) {
    	String enciphered = "";
        char upper = ' ';
    	
    	for (int i = 0; i < s.length(); i++) {
            if(Character.isLetter(s.charAt(i))){
                upper = Character.toUpperCase(s.charAt(i));
                int index = ALPHA.indexOf(upper);
                char new_char = ciphertext.charAt(index);
                enciphered += new_char;
            }
    	}

	return enciphered;
    }

}
