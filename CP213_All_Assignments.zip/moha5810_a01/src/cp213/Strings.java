package cp213;
import java.util.*;
/**
 * @author 
 * @version 2021-09-12
 */
public class Strings {
    // Constants
    public static final String VOWELS = "aeiouAEIOU";

    /**
     * Determines if string is a "palindrome": a word, verse, or sentence (such as "Able
     * was I ere I saw Elba") that reads the same backward or forward. Ignores case,
     * spaces, digits, and punctuation in the string parameter s.
     *
     * @param string a string
     * @return true if string is a palindrome, false otherwise
     */
    public static boolean isPalindrome(final String string) {
        boolean result = true;
        ArrayList<Character> temp = new ArrayList<>();

        for(int i = 0; i<string.length(); i++){
            if(Character.isLetter(string.charAt(i))){
              temp.add(Character.toLowerCase(string.charAt(i)));
            }
        }

        for(int i = 0, j = 1; i<temp.size(); i++, j++){
            int index = temp.size()-j;

            if(temp.get(i) != temp.get(index)){
                result = false;
            }
        }

	return result;
    }

    /**
     * Determines if name is a valid Java variable name. Variables names must start
     * with a letter or an underscore, but cannot be an underscore alone. The rest
     * of the variable name may consist of letters, numbers and underscores.
     *
     * @param name a string to test as a Java variable name
     * @return true if name is a valid Java variable name, false otherwise
     */
    public static boolean isValid(final String name) {

	boolean result = true;

    if(name.length() < 1){
        result = false;
        
    }

    else{
        if(name.length() == 1 && name.charAt(0) == '_'){
            result = false;
            
        }

        if(result){
            char temp = name.charAt(0);

            if(temp != '_' && Character.isLetter(temp) == false){
                result = false;
            }
    
            if(result){
                for(int i = 1; i < name.length(); i++){
                    if(name.charAt(i) != '_' && Character.isLetter(name.charAt(i)) == false && Character.isLetter(name.charAt(i)) == false){
                        result = false;
                    }
                }
            }
        }
    }



	return result;
    }

    /**
     * Converts a word to Pig Latin. The conversion is:
     * <ul>
     * <li>if a word begins with a vowel, add "way" to the end of the word.</li>
     * <li>if the word begins with consonants, move the leading consonants to the
     * end of the word and add "ay" to the end of that. "y" is treated as a
     * consonant if it is the first character in the word, and as a vowel for
     * anywhere else in the word.</li>
     * </ul>
     * Preserve the case of the word - i.e. if the first character of word is
     * upper-case, then the new first character should also be upper case.
     *
     * @param word The string to convert to Pig Latin
     * @return the Pig Latin version of word
     */
    public static String pigLatin(String word) {
        String result = "";
        String temp = "";
        char original = word.charAt(0);

        if(VOWELS.indexOf(word.charAt(0)) != -1){
            result = word;
            result = result + "way";
        }

        else{

            if(word.charAt(0) == 'y' || word.charAt(0) == 'Y'){
                temp = word.substring(0,1);
                word = word.substring(1) + temp.toLowerCase();              
            }

            for(int i = 0; i < word.length(); i++){
                if(VOWELS.indexOf(word.charAt(i)) == -1){//if char is consanant
                    temp = word.substring(0,1);
                    word = word.substring(1) + temp.toLowerCase();
                }
                if(VOWELS.indexOf(word.charAt(0)) != -1 || word.charAt(0) == 'y' || word.charAt(0) == 'Y'){//if char is vowel or a Y
                    i = word.length();
                }
            }
            result = word;
            result = result + "ay";
        }
        if(Character.isUpperCase(original)){
            temp = result.substring(0,1);
            result = temp.toUpperCase()+ result.substring(1); 
        }
        

	return result;
    }

}
