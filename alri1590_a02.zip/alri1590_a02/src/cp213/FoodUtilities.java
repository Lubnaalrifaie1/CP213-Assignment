package cp213;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Utilities for working with Food objects.
 *
 * @author Lubna AL Rifaie
 * @version 2022-02-06
 */
public class FoodUtilities {
	//All of the methods are explained in their documentation, which you can read in their source code, or at

    /**
     * Determines the average calories in a list of foods. No rounding necessary.
     * Foods list parameter may be empty.
     *
     * @param foods a list of Food
     * @return average calories in all Food objects
     */
    public static int averageCalories(final ArrayList<Food> foods) {
        int total = 0;
        //The following are notes to help you understand what is required for some of the classes.
        double average = 0;
        //Food are compared on the basis of their names and origin. Thus:
        if(foods.size() > 0){
        	//Food are compared on the basis of their names and origin. Thus:
            for(Food food : foods){
            	//Food are compared on the basis of their names and origin. Thus:
                total+=food.getCalories();
            }
            //Food.ORIGINS array (i.e. "Greek" has a smaller index than "English").
            average = (double) total/foods.size();
        }
        // the avarege is the double the total divded by food sizes

        /**
         * return value less than 0: current Food comes before the target Food.
			return value greater than 0: current Food comes after the target Food.
			return value equal to 0: the two food contain the same key values.
         */
	return (int) average;
    }

    /**
     * Determines the average calories in a list of foods for a particular origin.
     * No rounding necessary. Foods list parameter may be empty.
     *
     * @param foods  a list of Food
     * @param origin the origin of the Food
     * @return average calories for all Foods of the specified origin
     */
    public static int averageCaloriesByOrigin(final ArrayList<Food> foods, final int origin) {
       //the contents of this file if you like
    	int total = 0;
        // total is zero
        int average = 0;
        //int is avergae equal zero
        int counter = 0;
        // counter is equal zero

        /**
         * Determines the average calories in a list of foods. No rounding necessary.
         * Foods list parameter may be empty.
         *
         * @param foods a list of Food
         * @return average calories in all Food objects
         */
        if(foods.size() > 0){
        	// the food size has to be more than 0
            for(Food food : foods){
            	//All of the methods are explained in their documentation, which you can read in their source code, or at
                if(food.getOrigin() == origin){
                	//You can also see the results at: Sample Test Results. The file food.txt contains sample data for the Food class.
                    total+=food.getCalories();
                    //You can also see the results at: Sample Test Results. The file food.txt contains sample data for the Food class.
                    counter++;
                }
                // the code ends here
                
            }
            average = total/counter;
            //averge will equal total divded by the counter
        }

	return average;
	//import and use any libraries that are not part of the basic Java JDK installation
    }

    /**
     * Creates a list of foods by origin.
     *
     * @param foods  a list of Food
     * @param origin a food origin
     * @return a list of Food from origin
     */
    public static ArrayList<Food> getByOrigin(final ArrayList<Food> foods, final int origin) {

        ArrayList<Food> result = new ArrayList<Food>();
//returns a string that contains all of the Food origin names, formatted like:
        for(Food food : foods){
        	//returns a string that contains all of the Food origin names, formatted like:
            if(food.getOrigin() == origin){
            	//returns a string that provides a formatted version of a Food object. A formatted example:
                result.add(food);
                
            }
            /**
             * Follow the assignment instructions to 
             * the letter in terms of the Java project names 
             * and the Java class names, as this assignment 
             * will be auto-graded. If your Eclipse project and 
             * Java classes not defined correctly, the auto-grading fails,
             *  and your assignment 
             * will be given a mark of 0.
             */
        }
// code ends and returns result
	return result;
    }

    /**
     * Creates a Food object by requesting data from a user. Uses the format:
     *
     * <pre>
    Name: name
    Origins
     0 Canadian
     1 Chinese
    ...
    11 English
    Origin: origin number
    Vegetarian (Y/N): Y/N
    Calories: calories
     * </pre>
     *
     * @param keyboard a keyboard Scanner
     * @return a Food object
     */
    public static Food getFood(final Scanner keyboard) {
        boolean isVegetarian = false;
        //Think of this assignment as giving you more practice in your CP164 skills, but in Java and with more object-orientation

        System.out.println("Name: ");
        //Think of this assignment as giving you more practice in your CP164 skills, but in Java and with more object-orientation
        String name = keyboard.nextLine();
        //Marks will be deducted from any questions where these requirements are not met.

        System.out.println("Origin: ");
        //Marks will be deducted from any questions where these requirements are not met.
        Food.originsMenu();
        //Python has rules about what methods must be or can be defined in a class to
        int origin = keyboard.nextInt();
        //The special methods are not called by their names, but instead are called using
        keyboard.nextLine();
//To create a Student object, we need to have a constructor method defined. In
        System.out.println("Vegetarian (Y/N): ");
        String isVeg = keyboard.nextLine();

        System.out.println("Calories: ");
        // Code Listing 4, we have described what these values should be
        int calories = keyboard.nextInt();
//The only way to create a Student object is to call the Student constructor and pass 
        if(isVeg.equals("Y")){
        	//The only way to create a Student object is to call the Student constructor and pass 
            isVegetarian = true;
        }
        /**
         * Creates a list of vegetarian foods.
         *
         * @param foods a list of Food
         * @return a list of vegetarian Food
         */

        Food food = new Food(name, origin, isVegetarian, calories);

	return food;
    }

    /**
     * Creates a list of vegetarian foods.
     *
     * @param foods a list of Food
     * @return a list of vegetarian Food
     */
    public static ArrayList<Food> getVegetarian(final ArrayList<Food> foods) {

        ArrayList<Food> result = new ArrayList<Food>();
//If, however, we call the Student constructor and pass it this same data, as shown in Code Listing 1,
        for(Food food : foods){
        	//then the variable some_student
            if(food.isVegetarian()){
            	// then the variable some_student
                result.add(food);
            }
            //Getting Constructor Arguments From the Keyboard
        }

	return result;
	//Getting Constructor Arguments From the Keyboard
    }

    /**
     * Creates and returns a Food object from a line of string data.
     *
     * @param line a vertical bar-delimited line of food data in the format
     *             name|origin|isVegetarian|calories
     * @return the data from line as a Food object
     */
    public static Food readFood(final String line) {
        String[] stripped = line.split("\\|");
        //When creating an object, we need to pass the required
        String name = stripped[0];
        // the code has string name equal stripped 0
        int origin = Integer.parseInt(stripped[1]);
        //The program may ask the user to enter data
        boolean isVegetarian = true;
        //as the example below. The
        int calories = Integer.parseInt(stripped[3]);
        /**
         * Note the use of the 
         * Python docstring in the Student definition 
         * of __str__ to create a multi-line string. 
         * You can use string formatting with a docstring 
         * just as you would with a single-line string. 
         * The major drawback with a docstring is that 
         * the code indenting can be messed up.

			The only parameter to __str__ is self.
         */
        if(stripped[2].equals("false")){
        	//Comment out the part of the Student class defining the
            isVegetarian = false;
        }

        //s1 = Student("987654321", "Brown", "Tasmin", "F", 
        Food food = new Food(name, origin, isVegetarian, calories);

	return food;
    }

    /**
     * Reads a file of food strings into a list of Food objects.
     *
     * @param fileIn a Scanner of a Food data file in the format
     *               name|origin|isVegetarian|calories
     * @return a list of Food
     */
    public static ArrayList<Food> readFoods(final Scanner fileIn) {
        ArrayList<Food> objects = new ArrayList<Food>();
        //The first boolean method is the __eq__ method. It is often necessary to 
        while(fileIn.hasNextLine()){
        	//s1 = Student("987654321", "Brown", "Tasmin", "F", 
            String line = fileIn.nextLine();   
            //s1 = Student("987654321", "Brown", "Tasmin", "F", 
            Food result = readFood(line);
            //s1 = Student("987654321", "Brown", "Tasmin", "F", 
            objects.add(result);
        }
//The first boolean method is the __eq__ method. It is often necessary to 
	return objects;
    }

    /**
     * Searches for foods that fit certain conditions.
     *
     * @param foods        a list of Food
     * @param origin       the origin of the food; if -1, accept any origin
     * @param maxCalories  the maximum calories for the food; if 0, accept any
     * @param isVegetarian whether the food is vegetarian or not; if false accept
     *                     any
     * @return a list of foods that fit the conditions specified
     */
    public static ArrayList<Food> foodSearch(final ArrayList<Food> foods, final int origin, final int maxCalories, final boolean isVegetarian) {
        ArrayList<Food> result = new ArrayList<Food>();
        // Defining a __eq__ method for a class allows you to compare any two objects of the same class with the standard
        if(origin == -1){//no origin specified
        	//Defining a __eq__ method for a class allows you to compare any two objects of the same class with the standard
            if(isVegetarian){
            	//The method takes another Student object, called target, as a parameter.
                for(int i = 0; i < foods.size(); i++){
                	//The method takes another Student object, called target, as a parameter.
                    if(foods.get(i).getCalories() <= maxCalories && foods.get(i).isVegetarian() == isVegetarian){  
                    	//The method takes another Student object, called target, as a parameter.
                        result.add(foods.get(i));
                        //the result add foods
                    }
                    else if(maxCalories == 0 && foods.get(i).isVegetarian() == isVegetarian){
                    	//We never call __eq__ method by that name. In order to use this method, we use the == operator, as the method docstring notes:
                        result.add(foods.get(i));
                        //result add foods get
                    }
                }
            }
            /**
             * Defining a __lt__ method for a class allows 
             * you to use the < operator to compare two 
             * objects, as well as its negation, the >= 
             * operator. This method is defined in the 
             * Student class, and like the __ne__ method, 
             * the negation of __lt__, __ge__ (>=), 
             * is automatically defined by Python
             */
            else{
                for(int i = 0; i < foods.size(); i++){
                    if(foods.get(i).getCalories() <= maxCalories){  
                        result.add(foods.get(i));
                    }
                    //the result is max Claories
                    else if(maxCalories == 0){
                    	//Now we can compare two Student objects as in the following examples:
                        result.add(foods.get(i));
                    }
                }
            }
        }
        else{//origin specified
            if(isVegetarian){
                for(int i = 0; i < foods.size(); i++){
                    if(foods.get(i).getOrigin() == origin){
                        if(foods.get(i).getCalories() <= maxCalories && foods.get(i).isVegetarian() == isVegetarian){  
                            result.add(foods.get(i));
                        }
                        //the result is student
                        else if(maxCalories == 0 && foods.get(i).isVegetarian() == isVegetarian){
                            result.add(foods.get(i));
                        }  
                    }   
                    /**
                     * By putting the string values into 
                     * tuples, the function then compares 
                     * the two tuples to determine its result.
                     *  When comparing the Student attribute 
                     *  tuples, Python simply compares the 
                     *  elements of each tuple one after the
                     *   other, in effect duplicating the 
                     *   following code. Although this longer 
                     *   code is perfectly acceptable, the tuple 
                     *   shortcut is a nice one.
                     */
                }
            }
            else{
                for(int i = 0; i < foods.size(); i++){
                    if(foods.get(i).getOrigin() == origin){
                        if(foods.get(i).getCalories() <= maxCalories){ 
                            result.add(foods.get(i));
                        }
                        //Note that the code for __lt__ method uses a Python shortcut 
                        //to compare the names and IDs of two Student objects:
                        else if(maxCalories == 0){ 
                            result.add(foods.get(i));
                        }
                    }
                    //Python has a number of other magic method
                }
            }
            //Python has a number of other magic method
        }
        

	return result;
    }

    /**
     * Writes the contents of a list of Food to a PrintStream.
     *
     * @param foods a list of Food
     * @param ps    the PrintStream to write to
     */
    public static void writeFoods(final ArrayList<Food> foods, PrintStream ps) {
//To complete the full set of boolean methods on a Student object, we need to
        for(Food objects : foods){
        	//Now we can compare two Student objects as in the following examples:
            ps.println(objects);
        }
        ps.close();
        //Having defined all of the boolean operators ( ==, !=, <, >, <=, >= ) 
        // for the Student class, we can now use Python's built in list 
        // sort method to sort a list of Student objects.
    return;
    }
}
