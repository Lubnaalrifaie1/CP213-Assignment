package cp213;

import java.io.PrintStream;

/**
 * Food class definition.
 *
 * @author Lubna Al Rifaie
 * @version 2022-02-06
 */
public class Food implements Comparable<Food> {

    // Constants
    public static final String ORIGINS[] = { "Canadian", "Chinese", "Indian", "Ethiopian", "Mexican", "Greek",
	    "Japanese", "Italian", "Moroccan", "Scottish", "Columbian", "English" };

    /**
     * Creates a string of food origins in the format:
     *
     * <pre>
Origins
 0 Canadian
 1 Chinese
...
11 English
     * </pre>
     *
     * @return A formatted numbered string of valid food origins.
     */
    public static String originsMenu() {
    	System.out.print("Origins");
    	//for(int i = 0; i < ORIGINS.length; i++){
    	String food_origins = ""; 
    	//result = result.replaceAll("([\\n\\r]+\\s*)*$", "");
    	for(int i=0; i < Food.ORIGINS.length; i++){
    		if (i<=9) {
    		//Name:       Canuck Burger	
    			food_origins +="\n"+" "+i+" "+Food.ORIGINS[i] ;
    		}
    		// aways add stuff
    		else {
    		food_origins += "\n"+i+" "+Food.ORIGINS[i];
    		}
    	}
    		
    return food_origins;
    	        //Search for Vegetarian Italian foods under 300 calories
    }
    
    // Attributes
    private String name = null;
    private int origin = 0;
    //Test your programs thoroughly - show us how it works. Copy the outputs from your testing to a file in your Eclipse/Java project named
    private boolean isVegetarian = false;
    //Name:Diet Free-Range Gluten-free Water
    private int calories = 0;

    /**
     * Food constructor.
     *
     * @param name         food name
     * @param origin       food origin code
     * @param isVegetarian whether food is vegetarian
     * @param calories     caloric content of food
     */
    public Food(final String name, final int origin, final boolean isVegetarian, final int calories) {
    	super();
    	//You may use any code or libraries provided as a solution to previous labs or assignments if your own code or libraries are incomplete or incorrect.
    	this.name = name ; 
    	this.origin = origin ; 
    	this.isVegetarian = isVegetarian; 
    	this.calories = calories; 
    	
	// your code here

	return;
    }

    /*
     * (non-Javadoc) Compares this food against another food.
     *
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    /**
     * Foods are compared by name, then by origin if the names match.
     * Must ignore case.
     */
    @Override
    public int compareTo(final Food target) {
    	
    	if (target==null)
    		return 0;
    	/**
         * Foods are compared by name, then by origin if the names match.
         * Must ignore case.
         */
    	Food other = (Food)target; 
    	if (name.charAt(0) > other.name.charAt(0)) { 
    			return 1; 
    	}
    	else if (name.charAt(0) < other.name.charAt(0)) { 
    		return -1; 
    		//Follow the assignment instructions to the letter in terms of the Java project names and the Java class names, as this assignment will be auto-graded
    	} else if (name.toLowerCase().equals(other.name.toLowerCase())) {
    		//change any of the definitions in the code given, private to public, for example,
    		if (origin > other.origin)
    			//The file A02Main.java contains in-depth testing for these classes. You may update the contents of this file if you like. 
    			return 1; 
    		/**
    	     * Getter for isVegetarian attribute.
    	     *
    	     * @return isVegetarian
    	     */
    		//The project file testing.txt contains sample test results run from this main class
    		else if (origin == other.origin)
    			return 0; 
    		//The project file testing.txt contains sample test results run from this main class
    		else
    			return -1 ; 
    	}
    	
    	return 0;
    	//The following are notes to help you understand what is required for some of the classes.
    }
    

    /**
     * Getter for calories attribute.
     *
     * @return calories
     */
    public int getCalories() {
    	//returns a string that contains all of the Food origin names, formatted like:
    	return this.calories;
    }

	// your code here

    

    /**
     * Getter for name attribute.
     *
     * @return name
     */
    public String getName() {
    	return this.name; 
	// your code here


    }

    /**
     * Getter for origin attribute.
     *
     * @return origin
     */
    public int getOrigin() {
    	//returns a string that provides a formatted version of a Food object. A formatted example:
    	return this.origin; 
	// your code here

    }

    /**
     * Getter for string version of origin attribute.
     *
     * @return string version of origin
     */
    public String getOriginString() {
    	
	// compares two food and returns an integer that indicates the result of the comparison.

	return ORIGINS[this.origin];
    }

    /**
     * Getter for isVegetarian attribute.
     *
     * @return isVegetarian
     */
    public boolean isVegetarian() {

	// your code here

	return this.isVegetarian;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object//toString() Creates a formatted string of food data.
     */
    /**
     * Returns a string version of a Food object in the form:
<pre>
Name:       name
Origin:     origin string
Vegetarian: true/false
Calories:   calories
</pre>
     */
    @Override
    public String toString() {
    	String food_object = "";
    	food_object += String.format("Name: %-12s%n",this.name); 
    	food_object+=String.format("Origin: %-12s%n",ORIGINS[this.origin]); 
    	food_object+=String.format("Vegetarian: %-12s%n",this.isVegetarian); 
    	food_object+=String.format("Calories: %-12s%n", this.calories); 
    	
	return food_object;
    }

    /**
     * Writes a single line of food data to an open PrintStream. The contents of
     * food are written as a string in the format name|origin|isVegetarian|calories to ps.
     *
     * @param ps The PrintStream to write to.
     */
    public void write(final PrintStream ps) {
//    	PrintStream ps = new PrintStream(); 
    	String name = getName();
    	int origin = getOrigin(); 
    	//return value less than 0: current Food comes before the target Food.
    	int calories = getCalories();
    	//If the Food names match, then compare by origin number. Thus:
    	boolean isVegetarian = isVegetarian();
    	//because the string "Butter Chicken" comes before "Vegetable Alicha".
    	ps.printf(name,"|",origin,"|",isVegetarian,"|",calories);  
//because the origin "Greek" comes before the origin "English" in the
	return;
    }

}
