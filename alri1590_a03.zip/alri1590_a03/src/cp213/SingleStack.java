package cp213;

/**
 * A single linked stack structure of <code>Node T</code> objects. Only the
 * <code>T</code> value contained in the stack is visible through the standard
 * stack methods. Extends the <code>SingleLink</code> class. Note that the rear
 * attribute should be ignored as the rear is not used in a stack.
 *
 * @author Lubna Al Rifaie
 * @version 2022-03-06
 * @param <T> the SingleStack data type.
 */
public class SingleStack<T> extends SingleLink<T> {

    /**
     * Combines the contents of the left and right SingleStacks into the current
     * SingleStack. Moves nodes only - does not refer to values in any way, or call
     * the high-level methods pop or push. left and right SingleStacks are empty
     * when done. Nodes are moved alternately from left and right to this
     * SingleStack.
     *
     * You have two source stacks named left and right. Move all nodes from these
     * two stacks to the current stack. It does not make a difference if the current
     * stack is empty or not, just get nodes from the right and left stacks and add
     * them to the current stack. You may use any appropriate SingleLink helper
     * methods available.
     *
     * Do not assume that both right and left stacks are of the same length.
     *
     * @param left  The first SingleStack to extract nodes from.
     * @param right The second SingleStack to extract nodes from.
     */
    public void combine(final SingleStack<T> left, final SingleStack<T> right) {

        SingleNode<T> left_current = left.front;
        //Adds data to the top of
        //the stack. Increments the stack
        SingleNode<T> right_current = right.front;
        /**
         * Splits the contents of the current SingleStack into the left and right
         * SingleStacks. Moves nodes only - does not move value or call the high-level
         * methods insert or remove. this SingleStack is empty when done. Nodes are
         * moved alternately from this SingleStack to left and right. left and right may
         * already contain values.
         *
         * This is the opposite of the combine method.
         *
         * @param left  The first SingleStack to move nodes to.
         * @param right The second SingleStack to move nodes to.
         */


        this.front = new SingleNode<T>(left_current.getData(), null);//extract from left stack
      //Adds data to the top of
        //the stack. Increments the stack
        this.rear = this.front;
        /**
         * Splits the contents of the current SingleStack into the left and right
         * SingleStacks. Moves nodes only - does not move value or call the high-level
         * methods insert or remove. this SingleStack is empty when done. Nodes are
         * moved alternately from this SingleStack to left and right. left and right may
         * already contain values.
         *
         * This is the opposite of the combine method.
         *
         * @param left  The first SingleStack to move nodes to.
         * @param right The second SingleStack to move nodes to.
         */


        left_current = left_current.getNext();//update current node
      //Adds data to the top of
        //the stack. Increments the stack
        this.length++;
        /**
         * Splits the contents of the current SingleStack into the left and right
         * SingleStacks. Moves nodes only - does not move value or call the high-level
         * methods insert or remove. this SingleStack is empty when done. Nodes are
         * moved alternately from this SingleStack to left and right. left and right may
         * already contain values.
         *
         * This is the opposite of the combine method.
         *
         * @param left  The first SingleStack to move nodes to.
         * @param right The second SingleStack to move nodes to.
         */

        
        if(left.getLength() > right.getLength()){
        	//Adds data to the top of
            //the stack. Increments the stack
        	//run this if left stack is longer than right stack
            while(right_current != null){
            	//Adds data to the top of
                //the stack. Increments the stack
            	//alternate node swapping until right stack is finished
                this._push(right_current.getData());
                /**
                 * A single linked stack structure of <code>Node T</code> objects. Only the
                 * <code>T</code> value contained in the stack is visible through the standard
                 * stack methods. Extends the <code>SingleLink</code> class. Note that the rear
                 * attribute should be ignored as the rear is not used in a stack.
                 *
                 * @author David Brown
                 * @version 2022-02-06
                 * @param <T> the SingleStack data type.
                 */

                right_current = right_current.getNext();
              //Adds data to the top of
                //the stack. Increments the stack
                this._push(left_current.getData());
                /**
                 * A single linked stack structure of <code>Node T</code> objects. Only the
                 * <code>T</code> value contained in the stack is visible through the standard
                 * stack methods. Extends the <code>SingleLink</code> class. Note that the rear
                 * attribute should be ignored as the rear is not used in a stack.
                 *
                 * @author David Brown
                 * @version 2022-02-06
                 * @param <T> the SingleStack data type.
                 */

                left_current = left_current.getNext();
              //Adds data to the top of
                //the stack. Increments the stack
            }
            while(left_current != null){//finish pushing remaining nodes in left stack
            	//Adds data to the top of
                //the stack. Increments the stack
            	this._push(left_current.getData());
                
                /**
                 * A single linked stack structure of <code>Node T</code> objects. Only the
                 * <code>T</code> value contained in the stack is visible through the standard
                 * stack methods. Extends the <code>SingleLink</code> class. Note that the rear
                 * attribute should be ignored as the rear is not used in a stack.
                 *
                 * @author David Brown
                 * @version 2022-02-06
                 * @param <T> the SingleStack data type.
                 */

                left_current = left_current.getNext();
            }
          //Adds data to the top of
            //the stack. Increments the stack
        }

        else if(left.getLength() < right.getLength()){//run this if left stack is shorter than right stack
            while(left_current != null){
            	//Adds data to the top of
                //the stack. Increments the stack
            	//alternate node swapping until left stack is finished
                this._push(right_current.getData());
                /**
                 * A single linked stack structure of <code>Node T</code> objects. Only the
                 * <code>T</code> value contained in the stack is visible through the standard
                 * stack methods. Extends the <code>SingleLink</code> class. Note that the rear
                 * attribute should be ignored as the rear is not used in a stack.
                 *
                 * @author David Brown
                 * @version 2022-02-06
                 * @param <T> the SingleStack data type.
                 */

                right_current = right_current.getNext();
              //Adds data to the top of
                //the stack. Increments the stack
                this._push(left_current.getData());
                /**
                 * A single linked stack structure of <code>Node T</code> objects. Only the
                 * <code>T</code> value contained in the stack is visible through the standard
                 * stack methods. Extends the <code>SingleLink</code> class. Note that the rear
                 * attribute should be ignored as the rear is not used in a stack.
                 *
                 * @author David Brown
                 * @version 2022-02-06
                 * @param <T> the SingleStack data type.
                 */

                left_current = left_current.getNext();
            }
            while(right_current != null){//finish pushing remaining nodes in right stack
                this._push(right_current.getData());
                /**
                 * A single linked stack structure of <code>Node T</code> objects. Only the
                 * <code>T</code> value contained in the stack is visible through the standard
                 * stack methods. Extends the <code>SingleLink</code> class. Note that the rear
                 * attribute should be ignored as the rear is not used in a stack.
                 *
                 * @author David Brown
                 * @version 2022-02-06
                 * @param <T> the SingleStack data type.
                 */

                right_current = right_current.getNext();
            }
        }
        /**
         * Adds data to the top of the stack. Increments the stack length.
         *
         * @param data The value to add to the top of the stack.
         */

        else{//run this if both stacks are of same length
            while(right_current != null){
            	/**
                 * Adds data to the top of the stack. Increments the stack length.
                 *
                 * @param data The value to add to the top of the stack.
                 */

                this._push(right_current.getData());
                //Adds data to the top of
                //the stack. Increments the stack
                right_current = right_current.getNext();
                /**
                 * Adds data to the top of the stack. Increments the stack length.
                 *
                 * @param data The value to add to the top of the stack.
                 */

                this._push(left_current.getData());
                //public void push(final T data) 
                left_current = left_current.getNext();
            }
            /**
             * Combines the contents of the left and right SingleStacks into the current
             * SingleStack. Moves nodes only - does not refer to values in any way, or call
             * the high-level methods pop or push. left and right SingleStacks are empty
             * when done. Nodes are moved alternately from left and right to this
             * SingleStack.
             *
             * You have two source stacks named left and right. Move all nodes from these
             * two stacks to the current stack. It does not make a difference if the current
             * stack is empty or not, just get nodes from the right and left stacks and add
             * them to the current stack. You may use any appropriate SingleLink helper
             * methods available.
             *
             * Do not assume that both right and left stacks are of the same length.
             *
             * @param left  The first SingleStack to extract nodes from.
             * @param right The second SingleStack to extract nodes from.
             */

        }

        left.length = 0;
        //public void push(final T data) 
        left.front = null;
        /**
         * Combines the contents of the left and right SingleStacks into the current
         * SingleStack. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods pop or push. left and right SingleStacks are empty
         * when done. Nodes are moved alternately from left and right to this
         * SingleStack.
         *
         * You have two source stacks named left and right. Move all nodes from these
         * two stacks to the current stack. It does not make a difference if the current
         * stack is empty or not, just get nodes from the right and left stacks and add
         * them to the current stack. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left stacks are of the same length.
         *
         * @param left  The first SingleStack to extract nodes from.
         * @param right The second SingleStack to extract nodes from.
         */

        left.rear = null;
      //public void push(final T data) 

        right.length = 0;
        /**
         * Combines the contents of the left and right SingleStacks into the current
         * SingleStack. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods pop or push. left and right SingleStacks are empty
         * when done. Nodes are moved alternately from left and right to this
         * SingleStack.
         *
         * You have two source stacks named left and right. Move all nodes from these
         * two stacks to the current stack. It does not make a difference if the current
         * stack is empty or not, just get nodes from the right and left stacks and add
         * them to the current stack. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left stacks are of the same length.
         *
         * @param left  The first SingleStack to extract nodes from.
         * @param right The second SingleStack to extract nodes from.
         */

        right.front = null;
      //public void push(final T data) 
        right.rear = null;

	return;
    }

    /**
     * Returns the top value of the stack and removes that value from the stack. The
     * next node in the stack becomes the new top node. Decrements the stack length.
     *
     * @return The value at the top of the stack.
     */
    public T pop() {
    	//public void push(final T data) and the apperance

        T data = this.front.getData();
        /**
         * Combines the contents of the left and right SingleStacks into the current
         * SingleStack. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods pop or push. left and right SingleStacks are empty
         * when done. Nodes are moved alternately from left and right to this
         * SingleStack.
         *
         * You have two source stacks named left and right. Move all nodes from these
         * two stacks to the current stack. It does not make a difference if the current
         * stack is empty or not, just get nodes from the right and left stacks and add
         * them to the current stack. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left stacks are of the same length.
         *
         * @param left  The first SingleStack to extract nodes from.
         * @param right The second SingleStack to extract nodes from.
         */

        this.front = this.front.getNext();
      //public void push(final T data) and the apperance
        this.length --;

    return data;
    }

    /**
     * Adds data to the top of the stack. Increments the stack length.
     *
     * @param data The value to add to the top of the stack.
     */
    public void push(final T data) {
    	//public void push(final T data) and the apperance
    	if (this.getLength() == 0) {
    		/**
    	     * Combines the contents of the left and right SingleStacks into the current
    	     * SingleStack. Moves nodes only - does not refer to values in any way, or call
    	     * the high-level methods pop or push. left and right SingleStacks are empty
    	     * when done. Nodes are moved alternately from left and right to this
    	     * SingleStack.
    	     *
    	     * You have two source stacks named left and right. Move all nodes from these
    	     * two stacks to the current stack. It does not make a difference if the current
    	     * stack is empty or not, just get nodes from the right and left stacks and add
    	     * them to the current stack. You may use any appropriate SingleLink helper
    	     * methods available.
    	     *
    	     * Do not assume that both right and left stacks are of the same length.
    	     *
    	     * @param left  The first SingleStack to extract nodes from.
    	     * @param right The second SingleStack to extract nodes from.
    	     */

    		this.front = new SingleNode<T>(data,null);
    		//public void push(final T data) and the apperance
    		this.rear = this.front;
    		  		
    	} else {
    		/**
    	     * Combines the contents of the left and right SingleStacks into the current
    	     * SingleStack. Moves nodes only - does not refer to values in any way, or call
    	     * the high-level methods pop or push. left and right SingleStacks are empty
    	     * when done. Nodes are moved alternately from left and right to this
    	     * SingleStack.
    	     *
    	     * You have two source stacks named left and right. Move all nodes from these
    	     * two stacks to the current stack. It does not make a difference if the current
    	     * stack is empty or not, just get nodes from the right and left stacks and add
    	     * them to the current stack. You may use any appropriate SingleLink helper
    	     * methods available.
    	     *
    	     * Do not assume that both right and left stacks are of the same length.
    	     *
    	     * @param left  The first SingleStack to extract nodes from.
    	     * @param right The second SingleStack to extract nodes from.
    	     */

    		SingleNode<T> x = new SingleNode<T> (data,this.front);
    		//public void push(final T data) and the apperance
    		this.front = x;
    		
    	}
        this.length++;
        /**
         * Combines the contents of the left and right SingleStacks into the current
         * SingleStack. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods pop or push. left and right SingleStacks are empty
         * when done. Nodes are moved alternately from left and right to this
         * SingleStack.
         *
         * You have two source stacks named left and right. Move all nodes from these
         * two stacks to the current stack. It does not make a difference if the current
         * stack is empty or not, just get nodes from the right and left stacks and add
         * them to the current stack. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left stacks are of the same length.
         *
         * @param left  The first SingleStack to extract nodes from.
         * @param right The second SingleStack to extract nodes from.
         */


	return;
    }

    public void _push(final T data) {//hidden push
    	//public void push(final T data) and the apperance
    	if (this.getLength() == 0) {
    		/**
    	     * Combines the contents of the left and right SingleStacks into the current
    	     * SingleStack. Moves nodes only - does not refer to values in any way, or call
    	     * the high-level methods pop or push. left and right SingleStacks are empty
    	     * when done. Nodes are moved alternately from left and right to this
    	     * SingleStack.
    	     *
    	     * You have two source stacks named left and right. Move all nodes from these
    	     * two stacks to the current stack. It does not make a difference if the current
    	     * stack is empty or not, just get nodes from the right and left stacks and add
    	     * them to the current stack. You may use any appropriate SingleLink helper
    	     * methods available.
    	     *
    	     * Do not assume that both right and left stacks are of the same length.
    	     *
    	     * @param left  The first SingleStack to extract nodes from.
    	     * @param right The second SingleStack to extract nodes from.
    	     */

    		this.rear = this.front = new SingleNode<T>(data,null);
    		//public void push(final T data) and the apperance
    	} else {
    		/**
    	     * Combines the contents of the left and right SingleStacks into the current
    	     * SingleStack. Moves nodes only - does not refer to values in any way, or call
    	     * the high-level methods pop or push. left and right SingleStacks are empty
    	     * when done. Nodes are moved alternately from left and right to this
    	     * SingleStack.
    	     *
    	     * You have two source stacks named left and right. Move all nodes from these
    	     * two stacks to the current stack. It does not make a difference if the current
    	     * stack is empty or not, just get nodes from the right and left stacks and add
    	     * them to the current stack. You may use any appropriate SingleLink helper
    	     * methods available.
    	     *
    	     * Do not assume that both right and left stacks are of the same length.
    	     *
    	     * @param left  The first SingleStack to extract nodes from.
    	     * @param right The second SingleStack to extract nodes from.
    	     */

    		this.front = new SingleNode<T> (data,this.front);  		
    	}
    	//public void push(final T data) and the apperance
        this.length++;

	return;
    }

    /**
     * Splits the contents of the current SingleStack into the left and right
     * SingleStacks. Moves nodes only - does not move value or call the high-level
     * methods insert or remove. this SingleStack is empty when done. Nodes are
     * moved alternately from this SingleStack to left and right. left and right may
     * already contain values.
     *
     * This is the opposite of the combine method.
     *
     * @param left  The first SingleStack to move nodes to.
     * @param right The second SingleStack to move nodes to.
     */
    public void splitAlternate(final SingleStack<T> left, final SingleStack<T> right) {

        SingleNode<T> current = this.front;
      //public void push(final T data) and the apperance
        /**
         * Combines the contents of the left and right SingleStacks into the current
         * SingleStack. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods pop or push. left and right SingleStacks are empty
         * when done. Nodes are moved alternately from left and right to this
         * SingleStack.
         *
         * You have two source stacks named left and right. Move all nodes from these
         * two stacks to the current stack. It does not make a difference if the current
         * stack is empty or not, just get nodes from the right and left stacks and add
         * them to the current stack. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left stacks are of the same length.
         *
         * @param left  The first SingleStack to extract nodes from.
         * @param right The second SingleStack to extract nodes from.
         */

        
        left.front = new SingleNode<T>(current.getData(), null);
      //public void push(final T data) and the apperance
        left.rear = left.front;
        
        /**
         * Returns the top value of the stack and removes that value from the stack. The
         * next node in the stack becomes the new top node. Decrements the stack length.
         *
         * @return The value at the top of the stack.
         */


        current = this.front.getNext();
      //public void push(final T data) and 
        //the apperance

        right.front = new SingleNode<T>(current.getData(), null);
        /**
         * Returns the top value of the stack and removes that value from the stack. The
         * next node in the stack becomes the new top node. Decrements the stack length.
         *
         * @return The value at the top of the stack.
         */

        right.rear = right.front;
      //public void push(final T data) and 
        //the apperance

        current = current.getNext();
        /**
         * Returns the top value of the stack and removes that value from the stack. The
         * next node in the stack becomes the new top node. Decrements the stack length.
         *
         * @return The value at the top of the stack.
         */


        left.length++;
      //public void push(final T data) and 
        //the apperance
        right.length++;
        /**
         * Returns the top value of the stack and removes that value from the stack. The
         * next node in the stack becomes the new top node. Decrements the stack length.
         *
         * @return The value at the top of the stack.
         */

        this.length = this.length-2;

        while(current != null){
        	//public void push(final T data) and 
            //the apperance
            left._push(current.getData());
            /**
             * Returns the top value of the stack and removes that value from the stack. The
             * next node in the stack becomes the new top node. Decrements the stack length.
             *
             * @return The value at the top of the stack.
             */

            current = current.getNext();

            if(current != null){
            	//public void push(final T data) and 
                //the apperance
                right._push(current.getData());
                /**
                 * Returns the top value of the stack and removes that value from the stack. The
                 * next node in the stack becomes the new top node. Decrements the stack length.
                 *
                 * @return The value at the top of the stack.
                 */

                current = current.getNext();
              //public void push(final T data) and 
                //the apperance
            }
        }
        this.front = null;
        /**
         * Returns the top value of the stack and removes that value from the stack. The
         * next node in the stack becomes the new top node. Decrements the stack length.
         *
         * @return The value at the top of the stack.
         */

        this.rear = null;
      //public void push(final T data) and 
        //the apperance
        this.length = 0;
      //public void push(final T data) and 
        //the apperance
	return;
    }
}