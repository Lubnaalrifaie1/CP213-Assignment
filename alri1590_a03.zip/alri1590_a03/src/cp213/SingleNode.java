package cp213;

/**
 * DO NOT CHANGE THE CONTENTS OF THIS CLASS.
 *
 * The individual node of a linked structure that stores <code>T</code> objects.
 * This is a singly linked node. The node link can be updated, but not the node
 * data, in order to avoid copying or moving values between nodes. Data
 * structures must be updated by moving nodes, not by copying or moving data.
 *
 * @author Lubna Al Rifaie
 * @version 2022-03-06
 */
public final class SingleNode<T> {
	//Creates an intersection of two 
	 /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
	//other SingleLists into this 

    /**
     * The generic data.
     */
    private T data = null;
    /**
     * Link to the next Node.
     */
    private SingleNode<T> next = null;
	//Creates an intersection of two 
    /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
	//other SingleLists into this 

    /**
     * Creates a new node with data and link to next node. Not copy safe as it
     * accepts a reference to the data rather than a copy of the data.
     *
     * @param data the data to store in the node.
     * @param next  the next node to link to.
     */
    public SingleNode(final T data, final SingleNode<T> next) {
	this.data = data;
	//Creates an intersection of two 
	 /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
	//other SingleLists into this 
	this.next = next;
    }

    /**
     * Returns the node data. Not copy safe as it returns a reference to the data,
     * not a copy of the data.
     *
     * @return The data portion of the node.
     */
    public T getData() {
    	 /**
         * Creates an intersection of two other SingleLists into this SingleList. Copies
         * data to this SingleList. left and right SingleLists are unchanged. Values
         * from left are copied in order first, then values from right are copied in
         * order.
         *
         * @param left  The first SingleList to create an intersection from.
         * @param right The second SingleList to create an intersection from.
         */
    	//Creates an intersection of two 
    	//other SingleLists into this 
	return this.data;
    }

    /**
     * Returns the next node in the linked structure.
     *
     * @return The node that follows this node.
     */
    public SingleNode<T> getNext() {
    	//Creates an intersection of two 
    	 /**
         * Creates an intersection of two other SingleLists into this SingleList. Copies
         * data to this SingleList. left and right SingleLists are unchanged. Values
         * from left are copied in order first, then values from right are copied in
         * order.
         *
         * @param left  The first SingleList to create an intersection from.
         * @param right The second SingleList to create an intersection from.
         */
    	//other SingleLists into this 
	return this.next;
    }

    /**
     * Links this node to the next node.
     *
     * @param next The new node to link to.
     */
    public void setNext(final SingleNode<T> next) {
    	//Creates an intersection of two 
    	 /**
         * Creates an intersection of two other SingleLists into this SingleList. Copies
         * data to this SingleList. left and right SingleLists are unchanged. Values
         * from left are copied in order first, then values from right are copied in
         * order.
         *
         * @param left  The first SingleList to create an intersection from.
         * @param right The second SingleList to create an intersection from.
         */
    	//other SingleLists into this 
	this.next = next;
    }
}
