package cp213;

/**
 * A single linked priority queue structure of <code>Node T</code> objects.
 * These data objects must be Comparable - i.e. they must provide the compareTo
 * method. Only the <code>T</code> data contained in the priority queue is
 * visible through the standard priority queue methods. Extends the
 * <code>SingleLink</code> class.
 *
 * @author Lubna Al Rifaie
 * @version 2022-03-06
 * @param <T> data type for base data structure.
 */
public class SinglePriorityQueue<T extends Comparable<T>> extends SingleLink<T> {

    /**
     * Combines the contents of the left and right SinglePriorityQueues into the
     * current SinglePriorityQueue. Moves nodes only - does not move value or call
     * the high-level methods insert or remove. left and right SinglePriorityQueues
     * are empty when done. Nodes are moved alternately from left and right to this
     * SinglePriorityQueue. When finished all nodes must be in priority order from
     * front to rear.
     *
     * Do not use the SinglePriorityQueue insert and remove methods.
     *
     * Do not assume that both right and left priority queues are of the same
     * length.
     *
     * @param left  The first SinglePriorityQueue to extract nodes from.
     * @param right The second SinglePriorityQueue to extract nodes from.
     */
    public void combine(final SinglePriorityQueue<T> left, final SinglePriorityQueue<T> right) {
	assert this.front == null : "May combine into an empty Priority Queue only";

        SingleNode<T> current = left.front;
	    while(current != null){
            this._insert(current.getData());
            /**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

            current = current.getNext();
        }
        current = right.front;
	    while(current != null){
            this._insert(current.getData());
            /**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

            current = current.getNext();
        }

        left.front = null;
        left.rear = null;
        /**
         * Splits the contents of this SingleList into the left and right SingleLists.
         * Moves nodes only - does not move value or call the high-level methods insert
         * or remove. this SingleList is empty when done. The first half of this
         * SingleList is moved to left, and the last half of this SingleList is moved to
         * right. If the resulting lengths are not the same, left should have one more
         * item than right. Order is preserved.
         *
         * @param left  The first SingleList to move nodes to.
         * @param right The second SingleList to move nodes to.
         */

        left.length = 0;

        right.front = null;
        right.rear = null;
        /**
         * Splits the contents of this SingleList into the left and right SingleLists.
         * Moves nodes only - does not move value or call the high-level methods insert
         * or remove. this SingleList is empty when done. The first half of this
         * SingleList is moved to left, and the last half of this SingleList is moved to
         * right. If the resulting lengths are not the same, left should have one more
         * item than right. Order is preserved.
         *
         * @param left  The first SingleList to move nodes to.
         * @param right The second SingleList to move nodes to.
         */

        right.length = 0;
	return;
    }

    /**
     * Adds value to the SinglePriorityQueue. Data is stored in priority order, with
     * highest priority value at the front of the SinglePriorityQueue, and lowest at
     * the rear. Priority is determined by simple comparison - lower values have
     * higher priority. For example, 1 has a higher priority than 2 because 1 is a
     * lower value than 2. (Think of the phrase, "We're number one!" as an
     * indication of priority.)
     *
     * When inserting value to the priority queue, the queue must remain sorted.
     * Hence you need to find the proper location of inserting value. use the head
     * pointer to go through the queue. e.g., use SingleNode&lt;T&gt; current =
     * this.head;
     *
     * use current = current.getNext(); to traverse the queue.
     *
     * To get access to the value inside a node of queue use current.getValue().
     *
     * @param data value to insert in sorted order in priority queue.
     */
    public void insert(final T data) {
        int value = (Integer) data;

        //if the list is empty
        if(this.length == 0){
        	/**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

            this.front = new SingleNode<T>(data,null);
            this.rear = this.front;
            /**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

            this.length++;
        }
        //if front val > data
        else if ((Integer) this.front.getData() >= value) {
    		SingleNode<T> temp = new SingleNode<T>(data,this.front);
    		this.front = temp;
    		/**
    	     * Splits the contents of this SingleList into the left and right SingleLists.
    	     * Moves nodes only - does not move value or call the high-level methods insert
    	     * or remove. this SingleList is empty when done. The first half of this
    	     * SingleList is moved to left, and the last half of this SingleList is moved to
    	     * right. If the resulting lengths are not the same, left should have one more
    	     * item than right. Order is preserved.
    	     *
    	     * @param left  The first SingleList to move nodes to.
    	     * @param right The second SingleList to move nodes to.
    	     */

    		this.length++;
        }
        //if rear val < data
        else if((Integer) this.rear.getData() <= value){
    		this.rear.setNext(new SingleNode<T>(data,null));
    		this.rear = this.rear.getNext();  
    		/**
    	     * Splits the contents of this SingleList into the left and right SingleLists.
    	     * Moves nodes only - does not move value or call the high-level methods insert
    	     * or remove. this SingleList is empty when done. The first half of this
    	     * SingleList is moved to left, and the last half of this SingleList is moved to
    	     * right. If the resulting lengths are not the same, left should have one more
    	     * item than right. Order is preserved.
    	     *
    	     * @param left  The first SingleList to move nodes to.
    	     * @param right The second SingleList to move nodes to.
    	     */

            this.length++;   
        }
        
        else{
            SingleNode<T> current = this.front;
            //@param n The index of the item to return.

            SingleNode<T> previous = current;
            /**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

            boolean inserted = false;

            while(inserted != true){
            	
                if((Integer) current.getData() >= value) {         
                    previous.setNext(new SingleNode<T>(data, current));
                    /**
                     * Splits the contents of this SingleList into the left and right SingleLists.
                     * Moves nodes only - does not move value or call the high-level methods insert
                     * or remove. this SingleList is empty when done. The first half of this
                     * SingleList is moved to left, and the last half of this SingleList is moved to
                     * right. If the resulting lengths are not the same, left should have one more
                     * item than right. Order is preserved.
                     *
                     * @param left  The first SingleList to move nodes to.
                     * @param right The second SingleList to move nodes to.
                     */

                    inserted = true;
                    this.length++;
                    //@param n The index of the item to return.
                }
                previous = current;
                //@param n The index of the item to return.
                current = current.getNext();
            }
        }
        
	return;
    }

    public void _insert(final T data) {
    	 //@param n The index of the item to return.
        int value = (Integer) data;
        /**
         * Splits the contents of this SingleList into the left and right SingleLists.
         * Moves nodes only - does not move value or call the high-level methods insert
         * or remove. this SingleList is empty when done. The first half of this
         * SingleList is moved to left, and the last half of this SingleList is moved to
         * right. If the resulting lengths are not the same, left should have one more
         * item than right. Order is preserved.
         *
         * @param left  The first SingleList to move nodes to.
         * @param right The second SingleList to move nodes to.
         */


        //if the list is empty
        if(this.length == 0){
            this.front = new SingleNode<T>(data,null);
            //@param n The index of the item to return.
            this.rear = this.front;
            this.length++;
        }
        //if front val > data
        else if ((Integer) this.front.getData() >= value) {
        	/**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

    		SingleNode<T> temp = new SingleNode<T>(data,this.front);
    		 //@param n The index of the item to return.
    		this.front = temp;
    		/**
    	     * Splits the contents of this SingleList into the left and right SingleLists.
    	     * Moves nodes only - does not move value or call the high-level methods insert
    	     * or remove. this SingleList is empty when done. The first half of this
    	     * SingleList is moved to left, and the last half of this SingleList is moved to
    	     * right. If the resulting lengths are not the same, left should have one more
    	     * item than right. Order is preserved.
    	     *
    	     * @param left  The first SingleList to move nodes to.
    	     * @param right The second SingleList to move nodes to.
    	     */

    		this.length++;
        }
        //if rear val < data
        else if((Integer) this.rear.getData() <= value){
        	 //@param n The index of the item to return.
    		this.rear.setNext(new SingleNode<T>(data,null));
    		 //@param n The index of the item to return.
    		this.rear = this.rear.getNext(); 
    		/**
    	     * Splits the contents of this SingleList into the left and right SingleLists.
    	     * Moves nodes only - does not move value or call the high-level methods insert
    	     * or remove. this SingleList is empty when done. The first half of this
    	     * SingleList is moved to left, and the last half of this SingleList is moved to
    	     * right. If the resulting lengths are not the same, left should have one more
    	     * item than right. Order is preserved.
    	     *
    	     * @param left  The first SingleList to move nodes to.
    	     * @param right The second SingleList to move nodes to.
    	     */

            this.length++;   
        }
        
        else{
            SingleNode<T> current = this.front;
            //@param n The index of the item to return.
            SingleNode<T> previous = current;
            /**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

            boolean inserted = false;

            while(inserted != true){
            	 //@param n The index of the item to return.
                if((Integer) current.getData() >= value) {         
                    previous.setNext(new SingleNode<T>(data, current));
                    /**
                     * Splits the contents of this SingleList into the left and right SingleLists.
                     * Moves nodes only - does not move value or call the high-level methods insert
                     * or remove. this SingleList is empty when done. The first half of this
                     * SingleList is moved to left, and the last half of this SingleList is moved to
                     * right. If the resulting lengths are not the same, left should have one more
                     * item than right. Order is preserved.
                     *
                     * @param left  The first SingleList to move nodes to.
                     * @param right The second SingleList to move nodes to.
                     */

                    inserted = true;
                    //@param n The index of the item to return.
                    this.length++;
                }
                previous = current;
                //@param n The index of the item to return.
                current = current.getNext();
            }
        }
        
	return;
    }

    /**
     * Returns the highest priority value in the SinglePriorityQueue. Decrements the
     * count.
     *
     * @return the highest priority value currently in the SinglePriorityQueue.
     */
    public T remove() {

        T value = this.front.getData();
        /**
         * Splits the contents of this SingleList into the left and right SingleLists.
         * Moves nodes only - does not move value or call the high-level methods insert
         * or remove. this SingleList is empty when done. The first half of this
         * SingleList is moved to left, and the last half of this SingleList is moved to
         * right. If the resulting lengths are not the same, left should have one more
         * item than right. Order is preserved.
         *
         * @param left  The first SingleList to move nodes to.
         * @param right The second SingleList to move nodes to.
         */

        this.front = this.front.getNext();
        //@param n The index of the item to return.
        this.length--;

	return value;
    }

    /**
     * Splits the contents of this SinglePriorityQueue into the higher and lower
     * SinglePriorityQueue. Moves nodes only - does not move value or call the
     * high-level methods insert or remove. this SinglePriorityQueue is empty when
     * done. Nodes with priority value higher than key are moved to the
     * SinglePriorityQueue higher. Nodes with a priority value lower than or equal
     * to key are moved to the SinglePriorityQueue lower.
     *
     * Do not use the SinglePriorityQueue insert and remove methods.
     *
     * @param key    value to compare against node values in SinglePriorityQueue
     * @param higher an initially empty SinglePriorityQueue queue that ends up with
     *               all values with priority higher than key.
     * @param lower  an initially empty SinglePriorityQueue queue that ends up with
     *               all values with priority lower than or equal to key.
     */
    public void splitByKey(final T key, final SinglePriorityQueue<T> higher, final SinglePriorityQueue<T> lower) {

        SingleNode<T> current = this.front;
        //@param n The index of the item to return.
	    while(current.getData() != key){
	    	/**
	         * Splits the contents of this SingleList into the left and right SingleLists.
	         * Moves nodes only - does not move value or call the high-level methods insert
	         * or remove. this SingleList is empty when done. The first half of this
	         * SingleList is moved to left, and the last half of this SingleList is moved to
	         * right. If the resulting lengths are not the same, left should have one more
	         * item than right. Order is preserved.
	         *
	         * @param left  The first SingleList to move nodes to.
	         * @param right The second SingleList to move nodes to.
	         */

            higher._insert(current.getData());
            //@param n The index of the item to return.
            current = current.getNext();
        }
        while(current != null){
        	 //@param n The index of the item to return.
            lower._insert(current.getData());
            /**
             * Splits the contents of this SingleList into the left and right SingleLists.
             * Moves nodes only - does not move value or call the high-level methods insert
             * or remove. this SingleList is empty when done. The first half of this
             * SingleList is moved to left, and the last half of this SingleList is moved to
             * right. If the resulting lengths are not the same, left should have one more
             * item than right. Order is preserved.
             *
             * @param left  The first SingleList to move nodes to.
             * @param right The second SingleList to move nodes to.
             */

            current = current.getNext();
            //@param n The index of the item to return.
        }

        this.front = null;
        //@param n The index of the item to return.
        this.rear = null;
        /**
         * Splits the contents of this SingleList into the left and right SingleLists.
         * Moves nodes only - does not move value or call the high-level methods insert
         * or remove. this SingleList is empty when done. The first half of this
         * SingleList is moved to left, and the last half of this SingleList is moved to
         * right. If the resulting lengths are not the same, left should have one more
         * item than right. Order is preserved.
         *
         * @param left  The first SingleList to move nodes to.
         * @param right The second SingleList to move nodes to.
         */

        this.length = 0;
        //@param n The index of the item to return.
	return;
    }
}
