package cp213;

/**
 * A single linked queue structure of <code>Node T</code> objects. Only the
 * <code>T</code> value contained in the queue is visible through the standard
 * queue methods. Extends the <code>SingleLink</code> class.
 *
 * @author Lubna Al Rifaie
 * @version 2022-03-06
 * @param <T> the SingleQueue data type.
 */
public class SingleQueue<T> extends SingleLink<T> {

    /**
     * Combines the contents of the left and right SingleQueues into the current
     * SingleQueue. Moves nodes only - does not refer to values in any way, or call
     * the high-level methods insert or remove. left and right SingleQueues are
     * empty when done. Nodes are moved alternately from left and right to this
     * SingleQueue.
     *
     * You have two source queues named left and right. Move all nodes from these
     * two queues to the current queue. It does not make a difference if the current
     * queue is empty or not, just get nodes from the right and left queues and add
     * them to the current queue. You may use any appropriate SingleLink helper
     * methods available.
     *
     * Do not assume that both right and left queues are of the same length.
     *
     * @param left  The first SingleQueue to extract nodes from.
     * @param right The second SingleQueue to extract nodes from.
     */
    public void combine(final SingleQueue<T> left, final SingleQueue<T> right) {

        SingleNode<T> left_current = left.front;
        //A single linked queue structure of <code>Node 
        SingleNode<T> right_current = right.front;
        /**
         * Splits the contents of the current SingleQueue into the left and right
         * SingleQueues. Moves nodes only - does not move value or call the high-level
         * methods insert or remove. this SingleQueue is empty when done. Nodes are
         * moved alternately from this SingleQueue to left and right. left and right may
         * already contain values.
         *
         * This is the opposite of the combine method.
         *
         * @param left  The first SingleQueue to move nodes to.
         * @param right The second SingleQueue to move nodes to.
         */


        this.front = new SingleNode<T>(left_current.getData(), null);//extract from left stack
      //A single linked queue structure of <code>Node 
        this.rear = this.front;
        /**
         * Splits the contents of the current SingleQueue into the left and right
         * SingleQueues. Moves nodes only - does not move value or call the high-level
         * methods insert or remove. this SingleQueue is empty when done. Nodes are
         * moved alternately from this SingleQueue to left and right. left and right may
         * already contain values.
         *
         * This is the opposite of the combine method.
         *
         * @param left  The first SingleQueue to move nodes to.
         * @param right The second SingleQueue to move nodes to.
         */


        left_current = left_current.getNext();//update current node
      //A single linked queue structure of <code>Node 
        this.length++;
        /**
         * Splits the contents of the current SingleQueue into the left and right
         * SingleQueues. Moves nodes only - does not move value or call the high-level
         * methods insert or remove. this SingleQueue is empty when done. Nodes are
         * moved alternately from this SingleQueue to left and right. left and right may
         * already contain values.
         *
         * This is the opposite of the combine method.
         *
         * @param left  The first SingleQueue to move nodes to.
         * @param right The second SingleQueue to move nodes to.
         */

        
        if(left.getLength() > right.getLength()){//run this if left stack is longer than right stack
        	//A single linked queue structure of <code>Node 
        	while(right_current != null){//alternate node swapping until right stack is finished
            	//A single linked queue structure of <code>Node 
            	/**
                 * Adds value to the rear of the queue. Increments the queue length.
                 *
                 * @param data The value to added to the rear of the queue.
                 */

                this._insert(right_current.getData());
              //A single linked queue structure of <code>Node 
                right_current = right_current.getNext();
                /**
                 * Splits the contents of the current SingleQueue into the left and right
                 * SingleQueues. Moves nodes only - does not move value or call the high-level
                 * methods insert or remove. this SingleQueue is empty when done. Nodes are
                 * moved alternately from this SingleQueue to left and right. left and right may
                 * already contain values.
                 *
                 * This is the opposite of the combine method.
                 *
                 * @param left  The first SingleQueue to move nodes to.
                 * @param right The second SingleQueue to move nodes to.
                 */

                this._insert(left_current.getData());
              //A single linked queue structure of <code>Node 
                left_current = left_current.getNext();
                /**
                 * Adds value to the rear of the queue. Increments the queue length.
                 *
                 * @param data The value to added to the rear of the queue.
                 */

            }
            while(left_current != null){//A single linked queue structure of <code>Node 
            	//A single linked queue structure of <code>Node 
                this._insert(left_current.getData());
                /**
                 * Splits the contents of the current SingleQueue into the left and right
                 * SingleQueues. Moves nodes only - does not move value or call the high-level
                 * methods insert or remove. this SingleQueue is empty when done. Nodes are
                 * moved alternately from this SingleQueue to left and right. left and right may
                 * already contain values.
                 *
                 * This is the opposite of the combine method.
                 *
                 * @param left  The first SingleQueue to move nodes to.
                 * @param right The second SingleQueue to move nodes to.
                 */

                left_current = left_current.getNext();
              //A single linked queue structure of <code>Node 
            }
        }
      //A single linked queue structure of <code>Node 

        else if(left.getLength() < right.getLength()){//run this if left stack is shorter than right stack
            while(left_current != null){//A single linked queue structure of <code>Node 
            	/**
                 * Splits the contents of the current SingleQueue into the left and right
                 * SingleQueues. Moves nodes only - does not move value or call the high-level
                 * methods insert or remove. this SingleQueue is empty when done. Nodes are
                 * moved alternately from this SingleQueue to left and right. left and right may
                 * already contain values.
                 *
                 * This is the opposite of the combine method.
                 *
                 * @param left  The first SingleQueue to move nodes to.
                 * @param right The second SingleQueue to move nodes to.
                 */

                this._insert(right_current.getData());
              //A single linked queue structure of <code>Node 
                right_current = right_current.getNext();
                /**
                 * Splits the contents of the current SingleQueue into the left and right
                 * SingleQueues. Moves nodes only - does not move value or call the high-level
                 * methods insert or remove. this SingleQueue is empty when done. Nodes are
                 * moved alternately from this SingleQueue to left and right. left and right may
                 * already contain values.
                 *
                 * This is the opposite of the combine method.
                 *
                 * @param left  The first SingleQueue to move nodes to.
                 * @param right The second SingleQueue to move nodes to.
                 */

                this._insert(left_current.getData());
              //A single linked queue structure of <code>Node 
                left_current = left_current.getNext();
                /**
                 * Returns the front value of the queue and removes that value from the queue.
                 * The next node in the queue becomes the new first node. Decrements the queue
                 * length.
                 *
                 * @return The value at the front of the queue.
                 */

            }
            while(right_current != null){//finish pushing remaining nodes in right stack
                this._insert(right_current.getData());
                /**
                 * Returns the front value of the queue and removes that value from the queue.
                 * The next node in the queue becomes the new first node. Decrements the queue
                 * length.
                 *
                 * @return The value at the front of the queue.
                 */
              //A single linked queue structure of <code>Node 

                right_current = right_current.getNext();
            }
        }

        else{//run this if both stacks are of same length
            while(right_current != null){
                /**
                 * Returns the front value of the queue and removes that value from the queue.
                 * The next node in the queue becomes the new first node. Decrements the queue
                 * length.
                 *
                 * @return The value at the front of the queue.
                 */

                this._insert(right_current.getData());
              //A single linked queue structure of <code>Node 
                right_current = right_current.getNext();
                /**
                 * Returns the front value of the queue and removes that value from the queue.
                 * The next node in the queue becomes the new first node. Decrements the queue
                 * length.
                 *
                 * @return The value at the front of the queue.
                 */

                this._insert(left_current.getData());
                left_current = left_current.getNext();
            }
        }
        /**
         * Returns the front value of the queue and removes that value from the queue.
         * The next node in the queue becomes the new first node. Decrements the queue
         * length.
         *
         * @return The value at the front of the queue.
         */


        left.length = 0;
      //A single linked queue structure of <code>Node 
        left.front = null;
        /**
         * Returns the front value of the queue and removes that value from the queue.
         * The next node in the queue becomes the new first node. Decrements the queue
         * length.
         *
         * @return The value at the front of the queue.
         */

        left.rear = null;
        /**
         * Adds value to the rear of the queue. Increments the queue length.
         *
         * @param data The value to added to the rear of the queue.
         */


        right.length = 0;
      //A single linked queue structure of <code>Node 
        right.front = null;
        /**
         * Returns the front value of the queue and removes that value from the queue.
         * The next node in the queue becomes the new first node. Decrements the queue
         * length.
         *
         * @return The value at the front of the queue.
         */

        right.rear = null;

	return;
    }

    /**
     * Adds value to the rear of the queue. Increments the queue length.
     *
     * @param data The value to added to the rear of the queue.
     */
    public void insert(final T data) {

        if(this.getLength() == 0){
            /**
             * Returns the front value of the queue and removes that value from the queue.
             * The next node in the queue becomes the new first node. Decrements the queue
             * length.
             *
             * @return The value at the front of the queue.
             */

            this.rear = new SingleNode<T>(data,null);
            this.front = this.rear;
            /**
             * Returns the front value of the queue and removes that value from the queue.
             * The next node in the queue becomes the new first node. Decrements the queue
             * length.
             *
             * @return The value at the front of the queue.
             */

        }          
            
        else{
            SingleNode<T> noodle = new SingleNode<T>(data,null);
            this.rear.setNext(noodle);
            /**
             * Returns the front value of the queue and removes that value from the queue.
             * The next node in the queue becomes the new first node. Decrements the queue
             * length.
             *
             * @return The value at the front of the queue.
             */

            this.rear = noodle;
        }
        /**
         * Adds value to the rear of the queue. Increments the queue length.
         *
         * @param data The value to added to the rear of the queue.
         */

            
        this.length++;
	return;
    }

    public void _insert(final T data) {//hidden insert
        if(this.getLength() == 0){
            /**
             * Returns the front value of the queue and removes that value from the queue.
             * The next node in the queue becomes the new first node. Decrements the queue
             * length.
             *
             * @return The value at the front of the queue.
             */

            this.front = this.rear = new SingleNode<T>(data,null);
        }                   
        /**
         * Adds value to the rear of the queue. Increments the queue length.
         *
         * @param data The value to added to the rear of the queue.
         */

        else{
            SingleNode<T> noodle = new SingleNode<T>(data,null);
            this.rear.setNext(noodle);
            /**
             * Returns the front value of the queue and removes that value from the queue.
             * The next node in the queue becomes the new first node. Decrements the queue
             * length.
             *
             * @return The value at the front of the queue.
             */

            this.rear = noodle;
            /**
             * Adds value to the rear of the queue. Increments the queue length.
             *
             * @param data The value to added to the rear of the queue.
             */

        }          
        this.length++;
	return;
    }

    /**
     * Returns the front value of the queue and removes that value from the queue.
     * The next node in the queue becomes the new first node. Decrements the queue
     * length.
     *
     * @return The value at the front of the queue.
     */
    public T remove() {
        T result = this.front.getData();
        /**
         * Adds value to the rear of the queue. Increments the queue length.
         *
         * @param data The value to added to the rear of the queue.
         */


        if(this.getLength() == 1){
            this.front = null;
            /**
             * Returns the front value of the queue and removes that value from the queue.
             * The next node in the queue becomes the new first node. Decrements the queue
             * length.
             *
             * @return The value at the front of the queue.
             */

            this.rear = null;
            this.length = 0;
        }
        /**
         * Combines the contents of the left and right SingleQueues into the current
         * SingleQueue. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods insert or remove. left and right SingleQueues are
         * empty when done. Nodes are moved alternately from left and right to this
         * SingleQueue.
         *
         * You have two source queues named left and right. Move all nodes from these
         * two queues to the current queue. It does not make a difference if the current
         * queue is empty or not, just get nodes from the right and left queues and add
         * them to the current queue. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left queues are of the same length.
         *
         * @param left  The first SingleQueue to extract nodes from.
         * @param right The second SingleQueue to extract nodes from.
         */

        else{
            this.front = this.front.getNext();
            this.length--;
            /**
             * Adds value to the rear of the queue. Increments the queue length.
             *
             * @param data The value to added to the rear of the queue.
             */

        }

	return result;
    }

    /**
     * Splits the contents of the current SingleQueue into the left and right
     * SingleQueues. Moves nodes only - does not move value or call the high-level
     * methods insert or remove. this SingleQueue is empty when done. Nodes are
     * moved alternately from this SingleQueue to left and right. left and right may
     * already contain values.
     *
     * This is the opposite of the combine method.
     *
     * @param left  The first SingleQueue to move nodes to.
     * @param right The second SingleQueue to move nodes to.
     */
    public void splitAlternate(final SingleQueue<T> left, final SingleQueue<T> right) {

        SingleNode<T> current = this.front;
        /**
         * Combines the contents of the left and right SingleQueues into the current
         * SingleQueue. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods insert or remove. left and right SingleQueues are
         * empty when done. Nodes are moved alternately from left and right to this
         * SingleQueue.
         *
         * You have two source queues named left and right. Move all nodes from these
         * two queues to the current queue. It does not make a difference if the current
         * queue is empty or not, just get nodes from the right and left queues and add
         * them to the current queue. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left queues are of the same length.
         *
         * @param left  The first SingleQueue to extract nodes from.
         * @param right The second SingleQueue to extract nodes from.
         */

        left.front = new SingleNode<T>(current.getData(), null);
        left.rear = left.front;
        /**
         * Adds value to the rear of the queue. Increments the queue length.
         *
         * @param data The value to added to the rear of the queue.
         */


        current = this.front.getNext();
        /**
         * Combines the contents of the left and right SingleQueues into the current
         * SingleQueue. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods insert or remove. left and right SingleQueues are
         * empty when done. Nodes are moved alternately from left and right to this
         * SingleQueue.
         *
         * You have two source queues named left and right. Move all nodes from these
         * two queues to the current queue. It does not make a difference if the current
         * queue is empty or not, just get nodes from the right and left queues and add
         * them to the current queue. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left queues are of the same length.
         *
         * @param left  The first SingleQueue to extract nodes from.
         * @param right The second SingleQueue to extract nodes from.
         */

        right.front = new SingleNode<T>(current.getData(), null);
        right.rear = right.front;
        /**
         * Adds value to the rear of the queue. Increments the queue length.
         *
         * @param data The value to added to the rear of the queue.
         */


        current = current.getNext();

        left.length++;
        /**
         * Adds value to the rear of the queue. Increments the queue length.
         *
         * @param data The value to added to the rear of the queue.
         */

        right.length++;
        /**
         * Combines the contents of the left and right SingleQueues into the current
         * SingleQueue. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods insert or remove. left and right SingleQueues are
         * empty when done. Nodes are moved alternately from left and right to this
         * SingleQueue.
         *
         * You have two source queues named left and right. Move all nodes from these
         * two queues to the current queue. It does not make a difference if the current
         * queue is empty or not, just get nodes from the right and left queues and add
         * them to the current queue. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left queues are of the same length.
         *
         * @param left  The first SingleQueue to extract nodes from.
         * @param right The second SingleQueue to extract nodes from.
         */

        this.length = this.length-2;

        while(current != null){
        	/**
             * Adds value to the rear of the queue. Increments the queue length.
             *
             * @param data The value to added to the rear of the queue.
             */

            left._insert(current.getData());
            /**
             * Combines the contents of the left and right SingleQueues into the current
             * SingleQueue. Moves nodes only - does not refer to values in any way, or call
             * the high-level methods insert or remove. left and right SingleQueues are
             * empty when done. Nodes are moved alternately from left and right to this
             * SingleQueue.
             *
             * You have two source queues named left and right. Move all nodes from these
             * two queues to the current queue. It does not make a difference if the current
             * queue is empty or not, just get nodes from the right and left queues and add
             * them to the current queue. You may use any appropriate SingleLink helper
             * methods available.
             *
             * Do not assume that both right and left queues are of the same length.
             *
             * @param left  The first SingleQueue to extract nodes from.
             * @param right The second SingleQueue to extract nodes from.
             */

            current = current.getNext();
            /**
             * Adds value to the rear of the queue. Increments the queue length.
             *
             * @param data The value to added to the rear of the queue.
             */

            if(current != null){
                right._insert(current.getData());
                /**
                 * Combines the contents of the left and right SingleQueues into the current
                 * SingleQueue. Moves nodes only - does not refer to values in any way, or call
                 * the high-level methods insert or remove. left and right SingleQueues are
                 * empty when done. Nodes are moved alternately from left and right to this
                 * SingleQueue.
                 *
                 * You have two source queues named left and right. Move all nodes from these
                 * two queues to the current queue. It does not make a difference if the current
                 * queue is empty or not, just get nodes from the right and left queues and add
                 * them to the current queue. You may use any appropriate SingleLink helper
                 * methods available.
                 *
                 * Do not assume that both right and left queues are of the same length.
                 *
                 * @param left  The first SingleQueue to extract nodes from.
                 * @param right The second SingleQueue to extract nodes from.
                 */

                current = current.getNext();
            }
        }
        this.front = null;
        /**
         * Combines the contents of the left and right SingleQueues into the current
         * SingleQueue. Moves nodes only - does not refer to values in any way, or call
         * the high-level methods insert or remove. left and right SingleQueues are
         * empty when done. Nodes are moved alternately from left and right to this
         * SingleQueue.
         *
         * You have two source queues named left and right. Move all nodes from these
         * two queues to the current queue. It does not make a difference if the current
         * queue is empty or not, just get nodes from the right and left queues and add
         * them to the current queue. You may use any appropriate SingleLink helper
         * methods available.
         *
         * Do not assume that both right and left queues are of the same length.
         *
         * @param left  The first SingleQueue to extract nodes from.
         * @param right The second SingleQueue to extract nodes from.
         */

        this.rear = null;
        this.length = 0;

	return;
    }
}
