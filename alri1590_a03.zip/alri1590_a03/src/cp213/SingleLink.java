package cp213;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * The abstract base class for singly-linked data structures. Provides
 * attributes and implementations for getLength, peek, isEmpty, append,
 * moveFrontToRear, moveFrontToFront, and iterator methods.
 *
 * @author Lubna Al Rifaie
 * @version 2022-03-06
 * @param <T> data type for structure.
 */
public abstract class SingleLink<T> implements Iterable<T> {

    /**
     * Creates an Iterator for the outer class. An iterator allows a program to walk
     * through the values in a data structure by using the hasNext and next methods.
     * Typical code:
     *
     * <pre>
    Iterator&lt;T&gt; iter = dataStructure.iterator();

    while(iter.hasNext()){
        T data = iter.next();
        ...
    }
     * </pre>
     *
     * It also allows the user of the enhanced for loop:
     *
     * <pre>
    for(T data : dataStructure){
        ...
    }
     * </pre>
     *
     * (Replace T with a concrete class such as String or Integer.)
     */
    private class SingleLinkIterator implements Iterator<T> {
	/**
	 * current is initialized to beginning of linked structure.
	 */
	private SingleNode<T> current = SingleLink.this.front;

	/*
	 * (non-Javadoc)
	 *
	 * @see java.util.Iterator#hasNext()
	 */
	@Override
	public boolean hasNext() {
		 /**
	     * Creates an intersection of two other SingleLists into this SingleList. Copies
	     * data to this SingleList. left and right SingleLists are unchanged. Values
	     * from left are copied in order first, then values from right are copied in
	     * order.
	     *
	     * @param left  The first SingleList to create an intersection from.
	     * @param right The second SingleList to create an intersection from.
	     */
	    return this.current != null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.util.Iterator#next()
	 */
	@Override
	public T next() {
		/**
		 * Protected helper method to move the front node of source to the front of
     * this. All front, rear, and length attributes are appropriately updated in
     * both SingleLink objects. O(1) operation - must not use loops. source must
     * contain at least one node, or the method throws an AssertionError.
     *
     * @param source The SingleLink to extract the front node from.

		 */
		//Searches for the first occurrence
	    T result = null;
	    //Searches for the first occurrence

	    if (this.current == null) {
	    	//key The value to look for.
	    	 /**
	         * Creates an intersection of two other SingleLists into this SingleList. Copies
	         * data to this SingleList. left and right SingleLists are unchanged. Values
	         * from left are copied in order first, then values from right are copied in
	         * order.
	         *
	         * @param left  The first SingleList to create an intersection from.
	         * @param right The second SingleList to create an intersection from.
	         */
		throw new NoSuchElementException();
		//key The value to look for.
	    } else {
	    	 /**
	         * Creates an intersection of two other SingleLists into this SingleList. Copies
	         * data to this SingleList. left and right SingleLists are unchanged. Values
	         * from left are copied in order first, then values from right are copied in
	         * order.
	         *
	         * @param left  The first SingleList to create an intersection from.
	         * @param right The second SingleList to create an intersection from.
	         */
	    	//Appends data to the end of this SingleList
		result = this.current.getData();
		//Appends data to the end of this 
		//SingleList
		/**
		 * Protected helper method to move the front node of source to the front of
     * this. All front, rear, and length attributes are appropriately updated in
     * both SingleLink objects. O(1) operation - must not use loops. source must
     * contain at least one node, or the method throws an AssertionError.
     *
     * @param source The SingleLink to extract the front node from.

		 */
		this.current = this.current.getNext();
		//Appends data to the end of this SingleList
	    }
	    //public void _append(final T data) { 
	    return result;
	    /**
		 * Protected helper method to move the front node of source to the front of
     * this. All front, rear, and length attributes are appropriately updated in
     * both SingleLink objects. O(1) operation - must not use loops. source must
     * contain at least one node, or the method throws an AssertionError.
     *
     * @param source The SingleLink to extract the front node from.

		 */
	    //public void _append(final T data) { 
	}
    }

    /**
     * First node of linked structure.
     */
    protected SingleNode<T> front = null;
    /**
     * Number of values currently stored in linked structure.
     */
    protected int length = 0;
    /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
    /**
     * Last node of linked structure.
     */
    protected SingleNode<T> rear = null;

    /**
     * Protected helper method to append the entire source to the rear of this.
     * source becomes empty. O(1) operation - must not use loops. source must
     * contain at least one node, or the method throws an AssertionError.
     *
     * @param source the nodes to append to the end of this.
     */
    protected void append(final SingleLink<T> source) {
    	//Removes duplicates from this SingleList
	assert source.front != null : "Cannot append an empty source";

	// Update this.
	if (this.front == null) {
		 /**
	     * Creates an intersection of two other SingleLists into this SingleList. Copies
	     * data to this SingleList. left and right SingleLists are unchanged. Values
	     * from left are copied in order first, then values from right are copied in
	     * order.
	     *
	     * @param left  The first SingleList to create an intersection from.
	     * @param right The second SingleList to create an intersection from.
	     */
		//public void _append(final T data) { 
	    // this is empty.
		/**
		 * Follow the assignment instructions to 
		 * the letter in terms of the 
		 * Java project names and the Java class names, 
		 * as this assignment will be auto-graded. 
		 * If your Eclipse project and Java classes 
		 * not defined correctly, the auto-grading fails, 
		 * and your assignment will be given a mark of 0.
		 */
	    this.front = source.front;
	    //Removes duplicates from this SingleList
	} else {
	    // Add source to rear of this.
	    this.rear.setNext(source.front);
	    //Removes duplicates from this SingleList
	}
	this.rear = source.rear;
	//Removes duplicates from this SingleList
	this.length += source.length;
	//Removes duplicates from this SingleList
	// Empty source.
	/**
	 * Follow the assignment instructions to 
	 * the letter in terms of the 
	 * Java project names and the Java class names, 
	 * as this assignment will be auto-graded. 
	 * If your Eclipse project and Java classes 
	 * not defined correctly, the auto-grading fails, 
	 * and your assignment will be given a mark of 0.
	 */
	source.front = null;
	//value formerly present in this SingleList.
	source.rear = null;
	/**
	 * Follow the assignment instructions to 
	 * the letter in terms of the 
	 * Java project names and the Java class names, 
	 * as this assignment will be auto-graded. 
	 * If your Eclipse project and Java classes 
	 * not defined correctly, the auto-grading fails, 
	 * and your assignment will be given a mark of 0.
	 */
	//value formerly present in this SingleList.
	source.length = 0;
	//value formerly present in this SingleList.
	return;
    }

    /**
     * Protected helper method to move the front node of source to the front of
     * this. All front, rear, and length attributes are appropriately updated in
     * both SingleLink objects. O(1) operation - must not use loops. source must
     * contain at least one node, or the method throws an AssertionError.
     *
     * @param source The SingleLink to extract the front node from.
     */
    protected void moveFrontToFront(final SingleLink<T> source) {
    	//Combines contents of two lists into a third
	assert source.front != null : "Cannot move nodes from an empty source";
	//Values are alternated from the
	//Determines if this SingleList contains key.
	final SingleNode<T> node = source.front;
	//Determines if this SingleList contains key.
	// Update source.
	/**
     * Inserts value into this SingleList at index i. If i greater than the length
     * of this SingleList, append data to the end of this SingleList.
     *
     * @param i     The index to insert the new data at.
     * @param data The new value to insert into this SingleList.
     */
	source.length--;
	// SingleNode<T> current = this.front;
	source.front = source.front.getNext();
	// SingleNode<T> current = this.front;

	if (source.front == null) {
		//current = current.getNext();
	    // Clean up source if empty.
	    source.rear = null;
	    /**
	     * Inserts value into this SingleList at index i. If i greater than the length
	     * of this SingleList, append data to the end of this SingleList.
	     *
	     * @param i     The index to insert the new data at.
	     * @param data The new value to insert into this SingleList.
	     */
	    //current = current.getNext();
	}
	node.setNext(this.front);
	//public boolean _contains(final T key) {

	// Update this.
	if (this.rear == null) {
		//public boolean _contains(final T key) {
	    this.rear = node;
	    //public boolean _contains(final T key) {
	}
	this.front = node;
	/**
     * Inserts value into this SingleList at index i. If i greater than the length
     * of this SingleList, append data to the end of this SingleList.
     *
     * @param i     The index to insert the new data at.
     * @param data The new value to insert into this SingleList.
     */
	//public boolean _contains(final T key) {
	this.length++;
	//public boolean _contains(final T key) {
	return;
    }

    /**
     * Protected helper method to move the front node of source to the rear of this.
     * All front, rear, and length attributes are appropriately updated in both
     * SingleLink objects. O(1) operation - must not use loops. source must contain
     * at least one node, or the method throws an AssertionError.
     *
     * @param source The SingleLink to extract the front node from.
     */
    protected void moveFrontToRear(final SingleLink<T> source) {
    	//Finds the number of times key appears in list.
	assert source.front != null : "Cannot move nodes from an empty source";
	//Finds the number of times key appears in list.
	final SingleNode<T> node = source.front;
	// Update source.
	source.length--;
	 /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
	//Finds the number of times key appears in list.
	source.front = source.front.getNext();
	//Finds the number of times key appears in list.

	if (source.front == null) {
		//Finds the number of times key appears in list.
	    // Clean up source if empty.
	    source.rear = null;
	    /**
	     * Inserts value into this SingleList at index i. If i greater than the length
	     * of this SingleList, append data to the end of this SingleList.
	     *
	     * @param i     The index to insert the new data at.
	     * @param data The new value to insert into this SingleList.
	     */
	    //Finds the number of times key appears in list.
	}
	//public int count(final T key) {
	node.setNext(null);
	//public int count(final T key) {
	 /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
	// Update this.
	if (this.rear == null) {
		//public int count(final T key) {
	    this.front = node;
	} else {
		//while(current != null){
	    this.rear.setNext(node);
	    /**
	     * Creates an intersection of two other SingleLists into this SingleList. Copies
	     * data to this SingleList. left and right SingleLists are unchanged. Values
	     * from left are copied in order first, then values from right are copied in
	     * order.
	     *
	     * @param left  The first SingleList to create an intersection from.
	     * @param right The second SingleList to create an intersection from.
	     */
	}
	//while(current != null){
	this.rear = node;
	this.length++;
	//Finds and returns the value in list that matches key.
	
	return;
    }

    /**
     * Returns the current number of values in the linked structure.
     *
     * @return the value of length.
     */
    public final int getLength() {
	return this.length;
	//Finds and returns the value in list that matches key.
    }

    /**
     * Determines whether the linked data structure is empty or not.
     *
     * @return true if data structure is empty, false otherwise.
     */
    public final boolean isEmpty() {
    	// boolean found = false;
    	 /**
         * Creates an intersection of two other SingleLists into this SingleList. Copies
         * data to this SingleList. left and right SingleLists are unchanged. Values
         * from left are copied in order first, then values from right are copied in
         * order.
         *
         * @param left  The first SingleList to create an intersection from.
         * @param right The second SingleList to create an intersection from.
         */
	return this.front == null;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Iterable#iterator()
     */
    @Override
    public final Iterator<T> iterator() {
	return new SingleLinkIterator();
    }

    /**
     * Returns a reference to the first value of the linked structure without
     * removing that value from the structure.
     *
     * @return The value in the front of the structure.
     */
    public final T peek() {
    	//public T get(final int n) throws ArrayIndexOutOfBoundsException {
	return this.front.getData();
    }
}
